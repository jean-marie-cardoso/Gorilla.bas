# sprites.py — compatible PyInstaller + Pygbag
import os
import sys
import pygame
from config import ASSETS_DIR, SPRITES, GORILLA_H_TARGET, SUN_W_TARGET, BANANA_H_TARGET


def resource_path(relative_path):
    """Chemin compatible PyInstaller, exécution locale et Pygbag."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def _load(path):
    return pygame.image.load(path).convert_alpha()


def _scale_to_height(img, h):
    if img.get_height() == 0:
        return img
    s = h / img.get_height()
    w = max(1, int(img.get_width() * s))
    return pygame.transform.smoothscale(img, (w, int(h)))


def _scale_to_width(img, w):
    if img.get_width() == 0:
        return img
    s = w / img.get_width()
    h = max(1, int(img.get_height() * s))
    return pygame.transform.smoothscale(img, (int(w), h))


class Sprites:
    def __init__(self):
        base = ASSETS_DIR
        self.gorilla_idle = _load(resource_path(os.path.join(base, SPRITES["gorilla_idle"])))
        self.gorilla_leftup = _load(resource_path(os.path.join(base, SPRITES["gorilla_leftup"])))
        self.gorilla_rightup = _load(resource_path(os.path.join(base, SPRITES["gorilla_rightup"])))
        self.sun = _load(resource_path(os.path.join(base, SPRITES["sun"])))
        self.banana = _load(resource_path(os.path.join(base, SPRITES["banana"])))

        self.gorilla_idle = _scale_to_height(self.gorilla_idle, GORILLA_H_TARGET)
        target_size = (self.gorilla_idle.get_width(), self.gorilla_idle.get_height())
        self.gorilla_leftup = pygame.transform.smoothscale(self.gorilla_leftup, target_size)
        self.gorilla_rightup = pygame.transform.smoothscale(self.gorilla_rightup, target_size)
        self.sun = _scale_to_width(self.sun, SUN_W_TARGET)
        self.banana = _scale_to_height(self.banana, int(BANANA_H_TARGET * 1.8))
