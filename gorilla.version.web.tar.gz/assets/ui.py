# ui.py — helpers UI
import pygame


def draw_center_text(surface, font, text, y, color=(255, 255, 255)):
    img = font.render(text, True, color)
    x = surface.get_width() // 2 - img.get_width() // 2
    surface.blit(img, (x, y))
