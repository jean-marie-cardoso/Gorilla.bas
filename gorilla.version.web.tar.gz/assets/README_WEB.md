# Gorillas — version navigateur avec Pygbag

## Installation

Dans le dossier du projet :

```bash
python3 -m pip install pygbag pygame
```

## Test local

```bash
python3 -m pygbag --template fullscreen.tmpl --ume_block 0 .
```

Ouvrir ensuite l'adresse affichée, généralement :

```text
http://localhost:8000
```

## Build exportable

```bash
python3 -m pygbag --build --template fullscreen.tmpl --ume_block 0 .
```

Le résultat sera dans :

```text
build/web/
```

## Important

Le dossier `assets` doit rester à côté de `main.py`.

Si le navigateur garde un écran noir après plusieurs essais, vider le cache ou faire un rechargement forcé de la page (`Cmd+Shift+R` sur Mac). Pygbag met l'archive du jeu en cache assez agressivement pendant les tests locaux.
