# intro.py — version web compatible Pygbag
import asyncio
import pygame
from config import FPS
from ui import draw_center_text


async def show_intro(game):
    waiting = True
    while waiting:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type == pygame.KEYDOWN or e.type == pygame.MOUSEBUTTONDOWN:
                waiting = False

        game.vsurf.fill((22, 140, 199))
        draw_center_text(game.vsurf, game.font_big, "GORILLAS — Remake QBASIC to Python", 60)
        draw_center_text(game.vsurf, game.font, "Version Web / Pygbag", 90)

        lines = [
            "Votre mission est de toucher votre adversaire",
            "avec la banane explosive en faisant varier l'angle",
            "et la puissance de votre lancer, en tenant compte",
            "du vent, de la gravite, et du decor urbain.",
            "",
            "La vitesse du vent est indiquee par une fleche",
            "en bas de l'ecran de jeu.",
            "",
            "Appuyez sur une touche pour continuer...",
        ]
        y = 150
        for line in lines:
            draw_center_text(game.vsurf, game.font, line, y)
            y += 24

        game.blit_scaled()
        pygame.display.flip()
        game.clock.tick(FPS)
        await asyncio.sleep(0)
