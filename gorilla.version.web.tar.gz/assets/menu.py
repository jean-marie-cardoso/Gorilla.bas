# menu.py — version web compatible Pygbag
import asyncio
import pygame
from browser_input import BrowserTextInput
from config import FPS
from ui import draw_center_text


def _select_game_mode(text):
    cleaned = (text or "").strip().lower()
    if cleaned.startswith("1") or cleaned.startswith("ia") or cleaned.startswith("solo"):
        return "solo_ai"
    return "two_players"


async def _ask_text(game, prompt, initial="", input_mode="text", pattern=""):
    text = initial
    cursor = True
    tc = 0.0
    html_input = BrowserTextInput()

    if html_input.available:
        html_input.show(prompt, text, "done", input_mode, pattern)

    try:
        pygame.key.start_text_input()
    except pygame.error:
        pass

    try:
        while True:
            if html_input.available:
                text = html_input.value()
                if html_input.cancelled():
                    return text.strip() or initial
                if html_input.submitted():
                    return text.strip() or initial

            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return initial
                if e.type == pygame.MOUSEBUTTONDOWN and html_input.available:
                    html_input.focus()
                if e.type == pygame.TEXTINPUT:
                    if e.text and e.text.isprintable():
                        text += e.text
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        return text.strip() or initial
                    if e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        return text.strip() or initial
                    if e.key == pygame.K_BACKSPACE:
                        text = text[:-1]

            game.vsurf.fill((22, 140, 199))
            draw_center_text(game.vsurf, game.font_big, prompt, 120)
            if not html_input.available:
                draw_center_text(game.vsurf, game.font, text + ("|" if cursor else ""), 170)
            game.blit_scaled()
            pygame.display.flip()

            dt = game.clock.tick(FPS) / 1000.0
            tc += dt
            if tc >= 0.5:
                tc = 0.0
                cursor = not cursor

            await asyncio.sleep(0)
    finally:
        html_input.hide()
        try:
            pygame.key.stop_text_input()
        except pygame.error:
            pass


async def run_menu(game):
    mode = await _ask_text(
        game,
        "Mode: 1 Solo IA / 2 Deux joueurs",
        "1",
        "numeric",
        "[12]*",
    )
    game.game_mode = _select_game_mode(mode)

    p1 = await _ask_text(game, "Nom du Joueur 1", "Player 1")
    game.players[0].name = p1 or "Player 1"

    if game.game_mode == "solo_target":
        game.players[1].name = "Cible"
    elif game.game_mode == "solo_ai":
        game.players[1].name = "IA"
    else:
        p2 = await _ask_text(game, "Nom du Joueur 2", "Player 2")
        game.players[1].name = p2 or "Player 2"

    gtxt = await _ask_text(
        game,
        f"Gravite (px/s^2) [def {int(game.gravity)}]",
        str(int(game.gravity)),
        "decimal",
        "[0-9.,\\-]*",
    )
    try:
        game.gravity = float(gtxt)
    except ValueError:
        pass

    stxt = await _ask_text(
        game,
        f"Score pour gagner [def {game.win_score}]",
        str(game.win_score),
        "numeric",
        "[0-9]*",
    )
    try:
        game.win_score = int(stxt)
    except ValueError:
        pass
