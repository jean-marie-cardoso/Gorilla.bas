# menu.py — version web compatible Pygbag
import asyncio
import pygame
from config import FPS
from ui import draw_center_text


async def _ask_text(game, prompt, initial=""):
    text = initial
    cursor = True
    tc = 0.0

    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return initial
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    return text.strip() or initial
                if e.key == pygame.K_RETURN:
                    return text.strip() or initial
                if e.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                else:
                    ch = e.unicode
                    if ch and ch.isprintable():
                        text += ch

        game.vsurf.fill((22, 140, 199))
        draw_center_text(game.vsurf, game.font_big, prompt, 120)
        draw_center_text(game.vsurf, game.font, text + ("|" if cursor else ""), 170)
        game.blit_scaled()
        pygame.display.flip()

        dt = game.clock.tick(FPS) / 1000.0
        tc += dt
        if tc >= 0.5:
            tc = 0.0
            cursor = not cursor

        await asyncio.sleep(0)


async def run_menu(game):
    p1 = await _ask_text(game, "Nom du Joueur 1", "Player 1")
    p2 = await _ask_text(game, "Nom du Joueur 2", "Player 2")
    game.players[0].name = p1 or "Player 1"
    game.players[1].name = p2 or "Player 2"

    gtxt = await _ask_text(game, f"Gravite (px/s^2) [def {int(game.gravity)}]", str(int(game.gravity)))
    try:
        game.gravity = float(gtxt)
    except ValueError:
        pass

    stxt = await _ask_text(game, f"Score pour gagner [def {game.win_score}]", str(game.win_score))
    try:
        game.win_score = int(stxt)
    except ValueError:
        pass
