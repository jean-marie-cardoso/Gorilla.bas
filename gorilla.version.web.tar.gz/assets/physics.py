# physics.py — physique du projectile
from pygame.math import Vector2
from config import VIRTUAL_W, VIRTUAL_H


def step_ballistic(pos, vel, gravity, wind, wind_accel_per_unit, dt):
    vel = Vector2(vel)
    pos = Vector2(pos)
    vel.x += wind * wind_accel_per_unit * dt
    vel.y += gravity * dt
    pos += vel * dt
    return pos, vel


def out_of_bounds(pos):
    return pos.x < -80 or pos.x > VIRTUAL_W + 80 or pos.y > VIRTUAL_H + 80 or pos.y < -300
