# graphics.py — v6.2
import pygame, random, math
from config import VIRTUAL_W, VIRTUAL_H, EXPLOSION_RADIUS, WIND_MAX, BANANA_ROT_SPEED, TEXT_COLOR

# Couleurs de base
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
SKY = (22, 140, 199)

# Palette de couleurs pour les bâtiments (dégradés gris/blanc)
BUILDING_COLORS = [
    (60, 60, 60),     # gris foncé
    (90, 90, 90),
    (120, 120, 120),
    (160, 160, 160),
    (200, 200, 200),
    (230, 230, 230)   # presque blanc
]

class City:
    def __init__(self):
        self.rects = []
        self.mask = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)

    def generate(self, rng: random.Random):
        n = rng.randint(12, 18)
        total_w = VIRTUAL_W - 20
        x = 10
        remaining = total_w
        widths = []
        for i in range(n):
            slots = n - i
            w = max(18, int(remaining / slots) + rng.randint(-8, 10))
            widths.append(w)
            remaining -= w
        if remaining > 0:
            widths[-1] += remaining

        heights = [rng.randint(int(VIRTUAL_H * 0.1), int(VIRTUAL_H * 0.6)) for _ in range(n)]
        self.rects.clear()
        x = 10
        for w, h in zip(widths, heights):
            top = VIRTUAL_H - h
            rect = pygame.Rect(x, top, w, h)
            self.rects.append(rect)
            x += w
        self.rebuild_mask()

    def rebuild_mask(self):
        self.mask.fill((0, 0, 0, 0))
        for rect in self.rects:
            # couleur du bâtiment choisie aléatoirement
            color = random.choice(BUILDING_COLORS)
            pygame.draw.rect(self.mask, (*color, 255), rect)

            # fenêtres aléatoires
            for yy in range(rect.top + 8, rect.bottom - 6, 12):   # espacement vertical
                for xx in range(rect.left + 6, rect.right - 6, 10):  # espacement horizontal
                    if random.random() < 0.4:  # probabilité allumée
                        pygame.draw.rect(self.mask, (250, 230, 120, 255), (xx, yy, 6, 8))

def explode_in_city(city: City, center):
    pygame.draw.circle(city.mask, (0, 0, 0, 0), center, EXPLOSION_RADIUS)

def draw_explosion_wave(vsurf, center, max_radius=40, color=(255,165,0)):
    """Dessine une onde d'explosion circulaire temporaire."""
    x, y = center
    for r in range(6, max_radius, 4):
        pygame.draw.circle(vsurf, color, (x, y), r, 2)

def draw_wind_indicator(vsurf, font, wind_value):
    panel = pygame.Rect(8, 32, 118, 44)
    panel_surf = pygame.Surface(panel.size, pygame.SRCALPHA)
    pygame.draw.rect(panel_surf, (4, 22, 34, 92), panel_surf.get_rect(), border_radius=8)
    pygame.draw.rect(panel_surf, (255, 255, 255, 38), panel_surf.get_rect(), 1, border_radius=8)
    vsurf.blit(panel_surf, panel.topleft)

    value = max(-WIND_MAX, min(WIND_MAX, wind_value))
    strength = 0 if WIND_MAX == 0 else min(1.0, abs(value) / float(WIND_MAX))
    dir_sign = 0 if value == 0 else (1 if value > 0 else -1)
    arrow_color = (250, 250, 245)
    if value > 0:
        arrow_color = (255, 190, 58)
    elif value < 0:
        arrow_color = (96, 216, 255)

    label = f"Vent: {value:+d}" if value else "Vent: 0"
    txt = font.render(label, True, (255, 235, 188))
    vsurf.blit(txt, (panel.x + 8, panel.y + 3))

    base_x = panel.x + 60
    base_y = panel.y + 30
    max_len = 38
    tip_x = base_x + int(dir_sign * (10 + strength * (max_len - 10))) if dir_sign else base_x

    pygame.draw.line(vsurf, (255, 255, 255), (base_x - max_len, base_y), (base_x + max_len, base_y), 1)
    for tick in (-max_len, -max_len // 2, 0, max_len // 2, max_len):
        tick_h = 7 if tick == 0 else 4
        pygame.draw.line(
            vsurf,
            (255, 255, 255),
            (base_x + tick, base_y - tick_h // 2),
            (base_x + tick, base_y + tick_h // 2),
            1,
        )

    if dir_sign:
        trail_color = (*arrow_color, 85)
        for offset in (16, 25, 34):
            trail_x = base_x - dir_sign * offset
            pygame.draw.line(vsurf, trail_color, (trail_x, base_y - 6), (trail_x + dir_sign * 12, base_y - 6), 1)

        pygame.draw.line(vsurf, arrow_color, (base_x, base_y), (tip_x, base_y), 4)
        pygame.draw.circle(vsurf, arrow_color, (base_x, base_y), 4)
        head = 9
        pygame.draw.polygon(
            vsurf,
            arrow_color,
            [
                (tip_x, base_y),
                (tip_x - dir_sign * head, base_y - 6),
                (tip_x - dir_sign * head, base_y + 6),
            ],
        )
    else:
        pygame.draw.circle(vsurf, arrow_color, (base_x, base_y), 6, 2)
        pygame.draw.circle(vsurf, arrow_color, (base_x, base_y), 2)

def draw_scene(vsurf, spr, city: City, players, banana_active, banana_pos,
               sun_rect, font, font_small, status_message, wind_value, banana_angle_deg):
    vsurf.fill(SKY)
    vsurf.blit(spr.sun, sun_rect)
    vsurf.blit(city.mask, (0, 0))

    # gorilles
    for p in players:
        img = spr.gorilla_idle
        if p.state == "leftup":
            img = spr.gorilla_leftup
        elif p.state == "rightup":
            img = spr.gorilla_rightup
        rect = img.get_rect(midbottom=(int(p.pos.x), int(p.pos.y)))
        vsurf.blit(img, rect)

    # banane (rotation)
    if banana_active:
        rotated = pygame.transform.rotate(spr.banana, banana_angle_deg % 360)
        rect = rotated.get_rect(center=(int(banana_pos.x), int(banana_pos.y)))
        vsurf.blit(rotated, rect)

    # HUD en haut
    hud = font.render(
        f"{players[0].name} {players[0].score} - {players[1].score} {players[1].name}",
        True, TEXT_COLOR
    )
    vsurf.blit(hud, (8, 6))

    # message en bas
    if status_message:
        t = font_small.render(status_message, True, TEXT_COLOR)
        vsurf.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, VIRTUAL_H - 60))

    # indicateur de vent
    draw_wind_indicator(vsurf, font_small, wind_value)
