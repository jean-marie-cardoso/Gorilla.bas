# graphics.py — v6.2
import pygame, random, math
from config import VIRTUAL_W, VIRTUAL_H, EXPLOSION_RADIUS, WIND_MAX, BANANA_ROT_SPEED, TEXT_COLOR

# Couleurs de base
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
SKY = (22, 140, 199)

# Palette de couleurs pour les bâtiments (dégradés gris/blanc)
BUILDING_COLORS = [
    (60, 60, 60),     # gris foncé
    (90, 90, 90),
    (120, 120, 120),
    (160, 160, 160),
    (200, 200, 200),
    (230, 230, 230)   # presque blanc
]

class City:
    def __init__(self):
        self.rects = []
        self.mask = pygame.Surface((VIRTUAL_W, VIRTUAL_H), pygame.SRCALPHA)

    def generate(self, rng: random.Random):
        n = rng.randint(12, 18)
        total_w = VIRTUAL_W - 20
        x = 10
        remaining = total_w
        widths = []
        for i in range(n):
            slots = n - i
            w = max(18, int(remaining / slots) + rng.randint(-8, 10))
            widths.append(w)
            remaining -= w
        if remaining > 0:
            widths[-1] += remaining

        heights = [rng.randint(int(VIRTUAL_H * 0.1), int(VIRTUAL_H * 0.6)) for _ in range(n)]
        self.rects.clear()
        x = 10
        for w, h in zip(widths, heights):
            top = VIRTUAL_H - h
            rect = pygame.Rect(x, top, w, h)
            self.rects.append(rect)
            x += w
        self.rebuild_mask()

    def rebuild_mask(self):
        self.mask.fill((0, 0, 0, 0))
        for rect in self.rects:
            # couleur du bâtiment choisie aléatoirement
            color = random.choice(BUILDING_COLORS)
            pygame.draw.rect(self.mask, (*color, 255), rect)

            # fenêtres aléatoires
            for yy in range(rect.top + 8, rect.bottom - 6, 12):   # espacement vertical
                for xx in range(rect.left + 6, rect.right - 6, 10):  # espacement horizontal
                    if random.random() < 0.4:  # probabilité allumée
                        pygame.draw.rect(self.mask, (250, 230, 120, 255), (xx, yy, 6, 8))

def explode_in_city(city: City, center):
    pygame.draw.circle(city.mask, (0, 0, 0, 0), center, EXPLOSION_RADIUS)

def draw_explosion_wave(vsurf, center, max_radius=40, color=(255,165,0)):
    """Dessine une onde d'explosion circulaire temporaire."""
    x, y = center
    for r in range(6, max_radius, 4):
        pygame.draw.circle(vsurf, color, (x, y), r, 2)

def draw_wind_indicator(vsurf, font, wind_value):
    base_y = VIRTUAL_H - 22
    base_x = VIRTUAL_W // 2
    max_len = 100
    length = 0 if WIND_MAX == 0 else int((abs(wind_value) / float(WIND_MAX)) * max_len)
    dir_sign = 1 if wind_value >= 0 else -1
    tip_x = base_x + dir_sign * length
    # baseline
    pygame.draw.line(vsurf, TEXT_COLOR, (base_x - max_len, base_y), (base_x + max_len, base_y), 2)
    # shaft
    pygame.draw.line(vsurf, TEXT_COLOR, (base_x, base_y), (tip_x, base_y), 4)
    # arrow head
    head = 15
    pygame.draw.polygon(
        vsurf, TEXT_COLOR,
        [(tip_x, base_y),
         (tip_x - dir_sign * head, base_y - head // 2),
         (tip_x - dir_sign * head, base_y + head // 2)]
    )
    # label
    txt = font.render(f"Vent: {wind_value}", True, TEXT_COLOR)
    vsurf.blit(txt, (10, VIRTUAL_H - 34))

def draw_scene(vsurf, spr, city: City, players, banana_active, banana_pos,
               sun_rect, font, font_small, status_message, wind_value, banana_angle_deg):
    vsurf.fill(SKY)
    vsurf.blit(spr.sun, sun_rect)
    vsurf.blit(city.mask, (0, 0))

    # gorilles
    for p in players:
        img = spr.gorilla_idle
        if p.state == "leftup":
            img = spr.gorilla_leftup
        elif p.state == "rightup":
            img = spr.gorilla_rightup
        rect = img.get_rect(midbottom=(int(p.pos.x), int(p.pos.y)))
        vsurf.blit(img, rect)

    # banane (rotation)
    if banana_active:
        rotated = pygame.transform.rotate(spr.banana, banana_angle_deg % 360)
        rect = rotated.get_rect(center=(int(banana_pos.x), int(banana_pos.y)))
        vsurf.blit(rotated, rect)

    # HUD en haut
    hud = font.render(
        f"{players[0].name} {players[0].score} - {players[1].score} {players[1].name}",
        True, TEXT_COLOR
    )
    vsurf.blit(hud, (8, 6))

    # message en bas
    if status_message:
        t = font_small.render(status_message, True, TEXT_COLOR)
        vsurf.blit(t, (VIRTUAL_W // 2 - t.get_width() // 2, VIRTUAL_H - 60))

    # flèche de vent en bas
    draw_wind_indicator(vsurf, font, wind_value)
