# browser_input.py — champ HTML pour clavier mobile dans Pygbag
import json


class BrowserTextInput:
    """Champ HTML utilise par les navigateurs mobiles pour afficher le clavier."""

    def __init__(self):
        self.available = self._ensure()

    def _eval(self, code):
        try:
            import platform

            if hasattr(platform, "window"):
                return platform.window.eval(code)
        except Exception:
            return None
        return None

    def _ensure(self):
        code = r"""
(() => {
  if (window.GorillaMobileInput) {
    return true;
  }

  const state = {
    value: "",
    submitted: false,
    cancelled: false
  };

  const panel = document.createElement("div");
  panel.id = "gorilla-mobile-input-panel";
  panel.style.cssText = [
    "position:fixed",
    "left:50%",
    "bottom:calc(14px + env(safe-area-inset-bottom))",
    "transform:translateX(-50%)",
    "z-index:2147483647",
    "display:none",
    "align-items:center",
    "gap:8px",
    "box-sizing:border-box",
    "width:min(92vw, 430px)",
    "padding:8px",
    "border:1px solid rgba(255,255,255,.35)",
    "border-radius:8px",
    "background:rgba(3,18,30,.94)",
    "box-shadow:0 10px 28px rgba(0,0,0,.35)"
  ].join(";");

  const input = document.createElement("input");
  input.id = "gorilla-mobile-text-input";
  input.type = "text";
  input.autocomplete = "off";
  input.autocorrect = "off";
  input.autocapitalize = "off";
  input.spellcheck = false;
  input.style.cssText = [
    "flex:1 1 auto",
    "min-width:0",
    "height:46px",
    "box-sizing:border-box",
    "border:0",
    "border-radius:6px",
    "padding:0 12px",
    "font:700 22px system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
    "letter-spacing:0",
    "color:#06111d",
    "background:#ffffff",
    "outline:2px solid transparent"
  ].join(";");

  const ok = document.createElement("button");
  ok.type = "button";
  ok.textContent = "OK";
  ok.style.cssText = [
    "flex:0 0 auto",
    "height:46px",
    "min-width:64px",
    "box-sizing:border-box",
    "border:0",
    "border-radius:6px",
    "padding:0 14px",
    "font:800 18px system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
    "letter-spacing:0",
    "color:#06111d",
    "background:#ffbd3f",
    "touch-action:manipulation"
  ].join(";");

  panel.appendChild(input);
  panel.appendChild(ok);
  document.body.appendChild(panel);

  const stopForGame = (event) => event.stopPropagation();
  [
    "keydown", "keyup", "keypress", "beforeinput", "input",
    "compositionstart", "compositionupdate", "compositionend",
    "pointerdown", "pointerup", "mousedown", "mouseup",
    "touchstart", "touchend"
  ].forEach((name) => {
    panel.addEventListener(name, stopForGame);
    input.addEventListener(name, stopForGame);
    ok.addEventListener(name, stopForGame);
  });

  const submit = () => {
    state.value = input.value;
    state.submitted = true;
  };

  input.addEventListener("input", () => {
    state.value = input.value;
  }, true);

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      submit();
    } else if (event.key === "Escape") {
      state.cancelled = true;
    }
  }, true);

  ok.addEventListener("click", (event) => {
    event.preventDefault();
    submit();
    input.focus({ preventScroll: true });
  }, true);

  window.GorillaMobileInput = {
    show(label, value, enterHint, inputMode, pattern) {
      state.value = value || "";
      state.submitted = false;
      state.cancelled = false;
      input.value = state.value;
      input.placeholder = label || "";
      input.enterKeyHint = enterHint || "done";
      input.inputMode = inputMode || "text";
      input.pattern = pattern || "";
      panel.style.display = "flex";
      window.requestAnimationFrame(() => {
        input.focus({ preventScroll: true });
      });
    },
    hide() {
      panel.style.display = "none";
      input.blur();
      state.submitted = false;
      state.cancelled = false;
    },
    focus() {
      input.focus({ preventScroll: true });
    },
    value() {
      return input.value || "";
    },
    submitted() {
      const wasSubmitted = state.submitted;
      state.submitted = false;
      return wasSubmitted;
    },
    cancelled() {
      const wasCancelled = state.cancelled;
      state.cancelled = false;
      return wasCancelled;
    }
  };

  return true;
})()
"""
        return bool(self._eval(code))

    def show(self, label, value="", enter_hint="done", input_mode="text", pattern=""):
        if self.available:
            self._eval(
                "window.GorillaMobileInput.show(%s, %s, %s, %s, %s)"
                % (
                    json.dumps(label),
                    json.dumps(value),
                    json.dumps(enter_hint),
                    json.dumps(input_mode),
                    json.dumps(pattern),
                )
            )

    def hide(self):
        if self.available:
            self._eval("window.GorillaMobileInput.hide()")

    def focus(self):
        if self.available:
            self._eval("window.GorillaMobileInput.focus()")

    def value(self):
        if not self.available:
            return ""
        value = self._eval("window.GorillaMobileInput.value()")
        return "" if value is None else str(value)

    def submitted(self):
        return bool(self.available and self._eval("window.GorillaMobileInput.submitted()"))

    def cancelled(self):
        return bool(self.available and self._eval("window.GorillaMobileInput.cancelled()"))


def clean_number_text(text):
    cleaned = []
    for ch in (text or "").replace(",", "."):
        if ch.isdigit() or ch in ".-":
            cleaned.append(ch)
    return "".join(cleaned)


def parse_number(text):
    try:
        return float((text or "").replace(",", "."))
    except ValueError:
        return None
