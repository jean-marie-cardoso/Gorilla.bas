# ai.py — adversaire autonome simple
import math

from pygame.math import Vector2

from config import VIRTUAL_H, VIRTUAL_W, WIND_ACCEL_PER_UNIT
from physics import out_of_bounds, step_ballistic


def _shot_start(game, shooter):
    img_h = game.spr.gorilla_idle.get_height()
    return Vector2(shooter.pos.x, shooter.pos.y - img_h - 10)


def _shot_velocity(shooter, right_player, angle_deg, power):
    ang = math.radians(angle_deg)
    vx = math.cos(ang) * power
    vy = math.sin(ang) * power
    if shooter is right_player:
        vx = -vx
    return Vector2(vx, -vy)


def _simulate_shot(game, shooter_idx, target_idx, angle_deg, power):
    shooter = game.players[shooter_idx]
    target = game.players[target_idx]
    target_center = Vector2(
        target.pos.x,
        target.pos.y - game.spr.gorilla_idle.get_height() // 2,
    )
    pos = _shot_start(game, shooter)
    vel = _shot_velocity(shooter, game.players[1], angle_deg, power)

    best_distance = 9999.0
    dt = 1.0 / 30.0
    ignore_self_time = 0.2

    for step in range(210):
        pos, vel = step_ballistic(
            pos,
            vel,
            game.gravity,
            game.wind,
            WIND_ACCEL_PER_UNIT,
            dt,
        )

        distance = pos.distance_to(target_center)
        best_distance = min(best_distance, distance)
        if step * dt > ignore_self_time and distance <= 35:
            return 0.0

        if out_of_bounds(pos):
            break

        x, y = int(pos.x), int(pos.y)
        if 0 <= x < VIRTUAL_W and 0 <= y < VIRTUAL_H:
            try:
                if game.city.mask.get_at((x, y)).a > 0:
                    return best_distance + 35.0
            except IndexError:
                break

    return best_distance


def choose_ai_shot(game, shooter_idx=1, target_idx=0):
    shots_taken = getattr(game, "ai_shots_taken", 0)
    game.ai_shots_taken = shots_taken + 1

    candidates = []
    for angle in range(24, 79, 4):
        for power in range(90, 361, 12):
            score = _simulate_shot(game, shooter_idx, target_idx, angle, power)
            candidates.append((score, angle, power))

    if not candidates:
        return 45.0, 180.0

    candidates.sort(key=lambda item: item[0])

    if shots_taken == 0:
        min_rank, max_rank = 12, 52
        angle_spread = 16.0
        power_spread = 0.28
        mistake_chance = 0.55
    elif shots_taken < 3:
        min_rank, max_rank = 5, 38
        angle_spread = 12.0
        power_spread = 0.22
        mistake_chance = 0.35
    else:
        min_rank, max_rank = 0, 22
        angle_spread = 9.0
        power_spread = 0.16
        mistake_chance = 0.22

    min_rank = min(min_rank, len(candidates) - 1)
    max_rank = min(max_rank, len(candidates))
    if max_rank <= min_rank:
        min_rank = 0
    _, angle, power = game.rng.choice(candidates[min_rank:max_rank])

    angle_error = game.rng.uniform(-angle_spread, angle_spread)
    power_error = game.rng.uniform(-power_spread, power_spread)
    if game.rng.random() < mistake_chance:
        angle_error += game.rng.choice((-1, 1)) * game.rng.uniform(6.0, angle_spread)
        power_error += game.rng.choice((-1, 1)) * game.rng.uniform(0.06, power_spread)

    angle = max(12.0, min(84.0, angle + angle_error))
    power = max(55.0, min(390.0, power * (1.0 + power_error)))
    return angle, power
