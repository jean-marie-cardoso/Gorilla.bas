# config.py — v6
# Resolution of the virtual surface (scaled to window)
VIRTUAL_W, VIRTUAL_H = 640, 400
FPS = 60

# Gameplay / physics
DEFAULT_GRAVITY = 220.0       # px/s^2 (vertical acceleration)
DEFAULT_WIN_SCORE = 3
WIND_MAX = 10                 # UI range [-10..+10]
WIND_ACCEL_PER_UNIT = 10       # px/s^2 horizontal accel per wind unit
EXPLOSION_RADIUS = 22

# Fonts
FONT_MAIN_SIZE = 18
FONT_SMALL_SIZE = 14
FONT_BIG_SIZE = 24
TEXT_COLOR = (255, 128, 0) 

# Sprites scaling targets
GORILLA_H_TARGET = 56
SUN_W_TARGET = 64
BANANA_H_TARGET = 14          # base banana height (will be *1.2)

# Banana rotation speed (deg/sec)
BANANA_ROT_SPEED = 360

# Assets
ASSETS_DIR = "assets"
SPRITES = {
    "gorilla_idle": "gorilla_idle.png",
    "gorilla_leftup": "gorilla_leftup.png",
    "gorilla_rightup": "gorilla_rightup.png",
    "sun": "sun.png",
    "banana": "banana.png",
}
