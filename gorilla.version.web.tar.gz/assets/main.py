# main.py — version Web Pygbag plein écran
import asyncio
import math
import random
import sys

import pygame
from pygame.math import Vector2

from config import *
from sprites import Sprites
from graphics import City, draw_scene, explode_in_city, draw_explosion_wave
from physics import step_ballistic, out_of_bounds
from action import ask_angle_power
from menu import run_menu
from intro import show_intro


class Player:
    def __init__(self, name, color):
        self.name = name
        self.color = color
        self.building_index = 0
        self.pos = Vector2(0, 0)
        self.score = 0
        self.state = "idle"


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Gorillas — Web")

        # Surface navigateur. Pygbag/SDL ajuste ensuite la taille du canvas.
        self.screen = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        self.fullscreen = False

        # Surface virtuelle du jeu. Elle est étirée ensuite sur toute la fenêtre.
        self.vsurf = pygame.Surface((VIRTUAL_W, VIRTUAL_H)).convert_alpha()

        self.font = pygame.font.SysFont("Arial", FONT_MAIN_SIZE, bold=True)
        self.font_small = pygame.font.SysFont("Arial", FONT_SMALL_SIZE)
        self.font_big = pygame.font.SysFont("Arial", FONT_BIG_SIZE, bold=True)

        self.spr = Sprites()
        self.rng = random.Random()

        self.players = [Player("Player 1", (200, 200, 255)), Player("Player 2", (255, 200, 120))]
        self.current_player = 0
        self.other_player = 1

        self.city = City()
        self.sun_rect = self.spr.sun.get_rect(center=(VIRTUAL_W // 2, 76))

        self.banana_active = False
        self.banana_pos = Vector2()
        self.banana_vel = Vector2()
        self.banana_angle = 0.0

        self.gravity = DEFAULT_GRAVITY
        self.wind = 0
        self.win_score = DEFAULT_WIN_SCORE

        self.status_message = ""

        self._ignore_self_timer = 0.0
        self._ignore_self_index = None

    def toggle_fullscreen(self):
        # En navigateur, le vrai plein écran est géré par la page.
        # On garde la touche F/F11 sans casser l'affichage.
        self.fullscreen = not self.fullscreen
        self.screen = pygame.display.set_mode((1280, 720), pygame.RESIZABLE)

    def blit_scaled(self):
        """Étire le jeu sur 100% du canvas, sans conserver le ratio.
        Cela supprime totalement les bandes grises/noires sur les côtés.
        """
        screen_w, screen_h = self.screen.get_size()
        if screen_w <= 0 or screen_h <= 0:
            return
        pygame.transform.smoothscale(self.vsurf, (screen_w, screen_h), self.screen)

    def new_city(self):
        self.city.generate(self.rng)
        left_idx = self.rng.randint(1, max(1, len(self.city.rects) // 3))
        right_idx = self.rng.randint(max(len(self.city.rects) // 3 * 2, left_idx + 1), len(self.city.rects) - 2)
        self.players[0].building_index = left_idx
        self.players[1].building_index = right_idx
        for p in self.players:
            b = self.city.rects[p.building_index]
            p.pos = Vector2(b.centerx, b.top)
            p.state = "idle"
        self.wind = self.rng.randint(-WIND_MAX, WIND_MAX)
        self.banana_active = False

    def draw_scene(self):
        draw_scene(
            self.vsurf, self.spr, self.city, self.players, self.banana_active,
            self.banana_pos, self.sun_rect, self.font, self.font_small,
            self.status_message, self.wind, self.banana_angle
        )

    def fire_banana(self, player, angle_deg, power):
        ang = math.radians(angle_deg)
        vx = math.cos(ang) * power
        vy = math.sin(ang) * power
        if player is self.players[1]:
            vx = -vx
        img_h = self.spr.gorilla_idle.get_height()
        start = Vector2(player.pos.x, player.pos.y - img_h - 10)
        self.banana_pos = start.copy()
        self.banana_vel = Vector2(vx, -vy)
        self.banana_active = True
        self.banana_angle = 0.0
        player.state = "leftup" if player is self.players[0] else "rightup"
        self._ignore_self_index = self.current_player
        self._ignore_self_timer = 0.2

    async def short_explosion_pause(self, x, y):
        draw_explosion_wave(self.vsurf, (x, y))
        self.blit_scaled()
        pygame.display.flip()
        await asyncio.sleep(0.15)

    async def update_banana(self, dt):
        if not self.banana_active:
            return None

        self.banana_pos, self.banana_vel = step_ballistic(
            self.banana_pos, self.banana_vel, self.gravity, self.wind, WIND_ACCEL_PER_UNIT, dt
        )
        self.banana_angle = (self.banana_angle + BANANA_ROT_SPEED * dt) % 360

        if self._ignore_self_timer > 0:
            self._ignore_self_timer -= dt
            if self._ignore_self_timer <= 0:
                self._ignore_self_index = None

        x, y = int(self.banana_pos.x), int(self.banana_pos.y)

        if out_of_bounds(self.banana_pos):
            self.banana_active = False
            self.players[self.current_player].state = "idle"
            return "miss"

        if y >= 0:
            try:
                px = self.city.mask.get_at((x, y))
                if px.a > 0:
                    explode_in_city(self.city, (x, y))
                    await self.short_explosion_pause(x, y)
                    self.banana_active = False
                    self.players[self.current_player].state = "idle"
                    return "block"
            except IndexError:
                pass

        for i, p in enumerate(self.players):
            if self._ignore_self_index is not None and i == self._ignore_self_index:
                continue
            center = Vector2(p.pos.x, p.pos.y - self.spr.gorilla_idle.get_height() // 2)
            if self.banana_pos.distance_to(center) <= 35:
                explode_in_city(self.city, (int(p.pos.x), int(p.pos.y)))
                await self.short_explosion_pause(int(p.pos.x), int(p.pos.y))
                self.banana_active = False
                self.players[self.current_player].state = "idle"
                return f"hit_p{i}"
        return None

    async def run(self):
        await show_intro(self)
        await run_menu(self)
        self.new_city()

        running = True
        while running:
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    running = False
                elif e.type == pygame.VIDEORESIZE:
                    self.screen = pygame.display.get_surface()
                elif e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        running = False
                    elif e.key in (pygame.K_F11, pygame.K_f):
                        self.toggle_fullscreen()
                    elif e.key == pygame.K_r and not self.banana_active:
                        self.new_city()

            if not self.banana_active:
                angle_power = await ask_angle_power(self, self.players[self.current_player])
                if angle_power is None:
                    running = False
                    continue
                angle, power = angle_power
                self.fire_banana(self.players[self.current_player], angle, power)

            dt = self.clock.tick(FPS) / 1000.0
            res = await self.update_banana(dt)

            shot_resolved = False
            if res in ("miss", "block"):
                shot_resolved = True
            elif res in ("hit_p0", "hit_p1"):
                hit_idx = 0 if res == "hit_p0" else 1
                winner = 1 - hit_idx
                self.players[winner].score += 1
                self.status_message = f"Point pour {self.players[winner].name}!"

                for frame in range(14):
                    self.players[winner].state = "leftup" if frame % 2 == 0 else "rightup"
                    self.draw_scene()
                    self.blit_scaled()
                    pygame.display.flip()
                    self.clock.tick(7)
                    await asyncio.sleep(0)

                self.players[winner].state = "idle"

                if self.players[winner].score >= self.win_score:
                    t = 0.0
                    while t < 2.5:
                        self.vsurf.fill((22, 140, 199))
                        title = f"{self.players[winner].name} remporte la partie !"
                        txt = self.font_big.render(title, True, (255, 255, 255))
                        self.vsurf.blit(txt, (VIRTUAL_W // 2 - txt.get_width() // 2, 150))
                        self.blit_scaled()
                        pygame.display.flip()
                        t += self.clock.tick(FPS) / 1000.0
                        await asyncio.sleep(0)
                    self.players[0].score = self.players[1].score = 0

                shot_resolved = True

            if shot_resolved:
                self.current_player, self.other_player = self.other_player, self.current_player
                if res in ("hit_p0", "hit_p1"):
                    self.new_city()

            self.draw_scene()
            self.blit_scaled()
            pygame.display.flip()
            await asyncio.sleep(0)

        pygame.quit()


async def main():
    game = Game()
    await game.run()


asyncio.run(main())
