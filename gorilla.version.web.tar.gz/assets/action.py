# action.py — version web compatible Pygbag
import asyncio
import pygame
from browser_input import BrowserTextInput, clean_number_text, parse_number
from config import FPS, TEXT_COLOR, VIRTUAL_W
from ui import draw_center_text


def draw_center_text_shadow(surface, font, text, y, color, shadow=(0, 0, 0)):
    draw_center_text(surface, font, text, y + 2, color=shadow)
    draw_center_text(surface, font, text, y, color=color)


async def ask_angle_power(game, player):
    angle = None
    power = None
    entering_angle = True
    text_angle = ""
    text_power = ""
    cursor = True
    tcur = 0.0
    html_input = BrowserTextInput()

    def submit_current_value():
        nonlocal angle, power, entering_angle, text_angle, text_power

        if entering_angle and text_angle.strip() != "":
            angle = parse_number(text_angle)
            if angle is not None:
                entering_angle = False
                if html_input.available:
                    html_input.show("Puissance", text_power, "done", "decimal", "[0-9.,\\-]*", "top-right")
        elif not entering_angle and text_power.strip() != "":
            power = parse_number(text_power)
            if power is not None:
                return True
        return False

    if html_input.available:
        html_input.show("Angle (degres)", text_angle, "next", "decimal", "[0-9.,\\-]*", "top-right")

    try:
        pygame.key.start_text_input()
    except pygame.error:
        pass

    try:
        while True:
            if html_input.available:
                if entering_angle:
                    text_angle = clean_number_text(html_input.value())
                else:
                    text_power = clean_number_text(html_input.value())
                if html_input.cancelled():
                    return None
                if html_input.submitted():
                    if submit_current_value():
                        return angle, power

            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    return None
                if e.type == pygame.MOUSEBUTTONDOWN and html_input.available:
                    html_input.focus()
                if e.type == pygame.TEXTINPUT:
                    chunk = clean_number_text(e.text)
                    if chunk:
                        if entering_angle:
                            text_angle += chunk
                        else:
                            text_power += chunk
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        return None
                    if e.key in (pygame.K_F11, pygame.K_f):
                        game.toggle_fullscreen()
                    if e.key == pygame.K_BACKSPACE:
                        if entering_angle:
                            text_angle = text_angle[:-1]
                        else:
                            text_power = text_power[:-1]
                    elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        if submit_current_value():
                            return angle, power

            game.draw_scene()

            screen_w, screen_h = game.screen.get_size()
            show_turn_text = not html_input.available or screen_w >= screen_h
            if show_turn_text:
                y = max(2, game.sun_rect.top - game.font_big.get_height() - 4)
                draw_center_text_shadow(
                    game.vsurf,
                    game.font_big,
                    f"Au tour de {player.name}",
                    y,
                    color=(255, 255, 255),
                )

            if not html_input.available:
                t0 = game.font.render(
                    f"ANGLE (deg): {text_angle + ('|' if cursor and entering_angle else '')}",
                    True,
                    TEXT_COLOR,
                )
                game.vsurf.blit(t0, (VIRTUAL_W - t0.get_width() - 20, 20))

                displayed_power = (
                    text_power + ("|" if cursor and not entering_angle else "")
                    if not entering_angle else ""
                )
                t1 = game.font.render(f"PUISSANCE : {displayed_power}", True, TEXT_COLOR)
                game.vsurf.blit(t1, (VIRTUAL_W - t1.get_width() - 20, 50))

            game.blit_scaled()
            pygame.display.flip()

            dt = game.clock.tick(FPS) / 1000.0
            tcur += dt
            if tcur >= 0.5:
                tcur = 0.0
                cursor = not cursor

            await asyncio.sleep(0)
    finally:
        html_input.hide()
        try:
            pygame.key.stop_text_input()
        except pygame.error:
            pass
