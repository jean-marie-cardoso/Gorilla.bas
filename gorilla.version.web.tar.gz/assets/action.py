# action.py — version web compatible Pygbag
import asyncio
import pygame
from config import VIRTUAL_W, VIRTUAL_H, FPS, TEXT_COLOR
from ui import draw_center_text


async def ask_angle_power(game, player):
    angle = None
    power = None
    entering_angle = True
    text_angle = ""
    text_power = ""
    cursor = True
    tcur = 0.0

    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return None
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    return None
                if e.key in (pygame.K_F11, pygame.K_f):
                    game.toggle_fullscreen()
                if e.key == pygame.K_BACKSPACE:
                    if entering_angle:
                        text_angle = text_angle[:-1]
                    else:
                        text_power = text_power[:-1]
                elif e.key == pygame.K_RETURN:
                    if entering_angle and text_angle.strip() != "":
                        try:
                            angle = float(text_angle)
                        except ValueError:
                            angle = None
                        if angle is not None:
                            entering_angle = False
                    elif not entering_angle and text_power.strip() != "":
                        try:
                            power = float(text_power)
                        except ValueError:
                            power = None
                        if power is not None:
                            return angle, power
                else:
                    ch = e.unicode
                    if ch and (ch.isdigit() or ch in ".-"):
                        if entering_angle:
                            text_angle += ch
                        else:
                            text_power += ch

        game.draw_scene()

        y = VIRTUAL_H - 60
        draw_center_text(game.vsurf, game.font_big, f"Au tour de {player.name}", y, color=player.color)

        t0 = game.font.render(
            f"ANGLE (deg): {text_angle + ('|' if cursor and entering_angle else '')}",
            True,
            TEXT_COLOR,
        )
        game.vsurf.blit(t0, (VIRTUAL_W - t0.get_width() - 20, 20))

        displayed_power = text_power + ("|" if cursor and not entering_angle else "") if not entering_angle else ""
        t1 = game.font.render(f"PUISSANCE : {displayed_power}", True, TEXT_COLOR)
        game.vsurf.blit(t1, (VIRTUAL_W - t1.get_width() - 20, 50))

        game.blit_scaled()
        pygame.display.flip()

        dt = game.clock.tick(FPS) / 1000.0
        tcur += dt
        if tcur >= 0.5:
            tcur = 0.0
            cursor = not cursor

        await asyncio.sleep(0)
