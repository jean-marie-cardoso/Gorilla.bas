# Gorillas — Python/Pygame (Modular v5)

Version propre et complète. Lance **`python main.py`** depuis ce dossier.

## Prérequis
```
pip install pygame
```

## Assets (à fournir par toi dans `assets/`)
- `gorilla_idle.png`
- `gorilla_leftup.png`
- `gorilla_rightup.png`
- `sun.png`
- `banana.png`

## Contrôles
- Menu : Entrer noms des joueurs, points gagnants, gravité (px/s²).
- Tour par tour :
  - **Angle (°)** : `0` vers l’adversaire, `90` vers le ciel.
  - **Puissance** : valeur libre (pas de limite).
- **F11** ou **F** : plein écran ↔ fenêtré.
- **R** : nouvelle ville (si pas de projectile en vol).
- **Échap** : quitter.

## Notes
- La banane part **au-dessus de la tête** du gorille.
- Trajectoire **balistique** : gravité (verticale) + vent (accélération horizontale).
- Indicateur de **vent en bas** : flèche orientée (gauche/droite), longueur = intensité.
